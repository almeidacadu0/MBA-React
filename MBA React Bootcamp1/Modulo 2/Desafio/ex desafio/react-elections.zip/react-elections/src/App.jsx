import ElectionsPage from './pages/ElectionsPage';

export default function App() {
  return (
    <div>
      <ElectionsPage />
    </div>
  );
}
