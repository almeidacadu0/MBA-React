export function getToday() {
  return '2021-01-17';
}
